﻿using System;
using ApiSisProducts.models;
using Microsoft.EntityFrameworkCore;

namespace ApiSisProducts.Contexts
{
    public class DBContextProducts : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categorys { get; set; }

        public DBContextProducts(DbContextOptions<DBContextProducts> options) : base(options)
        {

        }
    }
}
