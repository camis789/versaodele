﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiSisProducts.models;
using ApiSisProducts.Services.Interface;
using Microsoft.AspNetCore.Mvc;


namespace ApiSisProducts.Controllers
{
    [Route("api/[controller]")]
    public class CategoryController : Controller
    {
        private readonly ICategoryService CategoryService;

        public CategoryController(ICategoryService CategoryService)
        {
            this.CategoryService = CategoryService;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("list")]
        public List<Category> GetCategory()
        {
            return CategoryService.ListAllCategorys();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public ActionResult<bool> Post([FromBody]Category category)
        {
            if (!string.IsNullOrWhiteSpace(category.Name))
            {
                var result = CategoryService.AddCategory(category);
                return result;
            }
            else
            {
                return BadRequest();
            }
            
        }

       

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
