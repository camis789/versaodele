﻿using System;
using System.Collections.Generic;
using System.Linq;
using ApiSisProducts.Contexts;
using ApiSisProducts.models;
using ApiSisProducts.Repository.Interface;

namespace ApiSisProducts.Repository.Class
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly DBContextProducts _context;

        public CategoryRepository(DBContextProducts ctx)
        {
            _context = ctx;
        }

        public void Add(Category category)
        {
            _context.Categorys.Add(category);
            _context.SaveChanges();
        }

        public Category FindByName(string name)
        {
            return _context.Categorys.Where(x => x.Name == name).FirstOrDefault();
        }

        public Category FindById(int Id)
        {
            return _context.Categorys.Where(x => x.Id == Id).FirstOrDefault();
        }
        public List<Category> ListCategorys()
        {
            return _context.Categorys.ToList();
        }
    }
}
