﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiSisProducts.Contexts;
using ApiSisProducts.models;
using ApiSisProducts.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace ApiSisProducts.Repository.Class
{
    public class ProductRepository : IProductRepository
    {
        private readonly DBContextProducts _context;

        public ProductRepository(DBContextProducts ctx)
        {
            _context = ctx;
        }

        public void Add(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
        }

        public Product FindByBarCode(int barCode)
        {
            return _context.Products.Where(x => x.BarCode == barCode).FirstOrDefault();
        }

        public List<Product> ListProducts()
        {
            return _context.Products.ToList();
        }
    }
}
