﻿using System;
using System.Collections.Generic;
using ApiSisProducts.models;

namespace ApiSisProducts.Repository.Interface
{
    public interface ICategoryRepository
    {
        void Add(Category category);
        Category FindByName(string name);
        Category FindById(int Id);
        List<Category> ListCategorys();
    }
}
