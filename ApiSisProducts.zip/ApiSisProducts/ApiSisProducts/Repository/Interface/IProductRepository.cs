﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ApiSisProducts.models;

namespace ApiSisProducts.Repository.Interface
{
    public interface IProductRepository
    {
        void Add(Product product);
        Product FindByBarCode(int barCode);
        List<Product> ListProducts();
    }
}
