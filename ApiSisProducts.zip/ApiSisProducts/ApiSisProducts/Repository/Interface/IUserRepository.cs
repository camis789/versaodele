﻿using System;
using System.Collections.Generic;
using ApiSisProducts.models;

namespace ApiSisProducts.Repository.Interface
{
    public interface IUserRepository
    {
        void Add(User user);
        User FindEmail(string email);
        List<User> ListUser();
        User Login(string email, string password);
    }
}
