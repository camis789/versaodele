﻿using System;
using ApiSisProducts.models;
using ApiSisProducts.Repository.Interface;
using ApiSisProducts.Services.Interface;
using System.Collections.Generic;
using ApiSisProducts.Contexts;
using System.Linq;

namespace ApiSisProducts.Services.Class
{
    public class CategoryService : ICategoryService
    {

        private readonly ICategoryRepository categoryRepository;

        public CategoryService(ICategoryRepository categoryRepository)
        {
            this.categoryRepository = categoryRepository;
        }

        public List<Category> ListAllCategorys()
        {
            return categoryRepository.ListCategorys();
        }

        public bool AddCategory(Category category)
        {
            if (categoryRepository.FindByName(category.Name) == null)
            {
                categoryRepository.Add(category);
                return true;
            }
            else
            {
                return false;
            }

           
        }
        
    }
}
