﻿using System;
using System.Collections.Generic;
using ApiSisProducts.models;
using ApiSisProducts.Repository.Interface;
using ApiSisProducts.Services.Interface;

namespace ApiSisProducts.Services.Class
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository productRepository;
        private readonly ICategoryRepository categoryRepository;

        public ProductService(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            this.productRepository = productRepository;
            this.categoryRepository = categoryRepository;
        }

        public bool AddProduct(Product product)
        {
            if (productRepository.FindByBarCode(product.BarCode) == null)
            {
                product.Category = categoryRepository.FindById(product.Category.Id);
                productRepository.Add(product);
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Product> ListAllProducts()
        {
            return productRepository.ListProducts();
        }
    }
}
