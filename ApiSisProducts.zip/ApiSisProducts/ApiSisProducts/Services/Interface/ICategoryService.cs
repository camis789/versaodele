﻿using System;
using ApiSisProducts.models;
using System.Collections.Generic;

namespace ApiSisProducts.Services.Interface
{
    public interface ICategoryService
    {
        bool AddCategory(Category category);
        List<Category> ListAllCategorys();
    }
}
