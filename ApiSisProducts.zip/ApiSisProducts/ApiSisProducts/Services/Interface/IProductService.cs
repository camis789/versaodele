﻿using System;
using System.Collections.Generic;
using ApiSisProducts.models;

namespace ApiSisProducts.Services.Interface
{
    public interface IProductService
    {
        bool AddProduct(Product product);
        List<Product> ListAllProducts();
    }
}
