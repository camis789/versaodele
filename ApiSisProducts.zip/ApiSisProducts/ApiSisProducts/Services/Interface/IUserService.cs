﻿using System;
using System.Collections.Generic;
using ApiSisProducts.models;

namespace ApiSisProducts.Services.Interface
{
    public interface IUserService
    {
        bool AddUser(User user);
        List<User> ListUsers();
    }
}
